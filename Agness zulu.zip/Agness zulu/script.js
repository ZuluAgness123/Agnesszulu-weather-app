const cityInput = document.getElementById('city_input');
const searchBtn = document.getElementById('searchBtn');
const weatherDetailsSection = document.querySelector('.current-weather');
const forecastContainer = document.querySelector('.forecast-container');

async function fetchWeather(city) {
  const apiKey = "fa1218b2cd4274daf1a1476b937924b5";
  const url = `https://api.openweathermap.org/data/2.5/weather?q=${city}&appid=${apiKey}`;

  try {
    const response = await fetch(url);
    const data = await response.json();

    if (data.cod !== 200) {
      alert('City not found');
      return;
    }

    const temperature = (data.main.temp - 273.15).toFixed(1);
    const description = data.weather[0].description;
    const humidity = data.main.humidity;
    const windSpeed = data.wind.speed;

    weatherDetailsSection.innerHTML = `
      <div class="details">
        <p>Now</p>
        <h2>${temperature}°C</h2>
        <p>${description}</p>
        <p>Humidity: ${humidity}%</p>
        <p>Wind Speed: ${windSpeed} m/s</p>
      </div>
      <div class="weather-icon">
        <img src="https://openweathermap.org/img/wn/${data.weather[0].icon}@2x.png" alt="weather icon" />
      </div>
    `;
  } catch (error) {
    alert('Could not fetch data');
  }
}

// Search button functionality
searchBtn.addEventListener('click', async () => {
  const cityName = cityInput.value.trim();
  if (!cityName) {
    alert('Please type a city name');
    return;
  }
  await fetchWeather(cityName);
});

// Automatically fetch weather for Kabwe on first load
window.addEventListener('load', () => {
  fetchWeather('Kabwe');
});
